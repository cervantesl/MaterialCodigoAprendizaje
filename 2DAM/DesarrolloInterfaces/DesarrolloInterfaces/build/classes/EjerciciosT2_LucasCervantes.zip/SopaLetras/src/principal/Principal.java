package principal;

import vista.Ventana;

public class Principal {

	public static Ventana ventana;

	public static void main(String[] args) {
		ventana = new Ventana();
	}
}
